﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Microsoft.EntityFrameworkCore;

namespace S2G2_PVFApp.Data
{
    public class S2G2_PVFApp_DBContext : DbContext
    {
        public S2G2_PVFApp_DBContext(DbContextOptions<S2G2_PVFApp_DBContext> options)
        : base(options)
        { }
        public DbSet<CustomerEntity> Customers { get; set; }
        public DbSet<EmployeeEntity> Employees { get; set; }
        public DbSet<OrderEntity> Orders { get; set; }
        public DbSet<OrderLineEntity> OrderLines { get; set; }
        public DbSet<ProductEntity> Products { get; set; }
        public DbSet<ProductLineEntity> ProductLines { get; set; }
        public DbSet<RawMaterialEntity> RawMaterials { get; set; }
        public DbSet<SalesPersonEntity> SalesPersons { get; set; }
        public DbSet<SalesTerritoryEntity> SalesTerritories { get; set; }
        public DbSet<SkillEntity> Skills { get; set; }
        public DbSet<VendorEntity> Vendors { get; set; }
        public DbSet<WorkCenterEntity> WorkCenters { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            var converter = new ValueConverter<decimal, double>(
                v => (double)v,
                v => (decimal)v
            );
            modelBuilder.Entity<ProductEntity>().Property(a => a.Price).HasPrecision(7, 2);
            modelBuilder.Entity<RawMaterialEntity>().Property(a => a.Cost).HasPrecision(7, 2);

            modelBuilder.Entity<SalesPersonEntity>(entity =>
            {
                entity.HasKey(e => e.SalesPersonId);
            });
            modelBuilder.Entity<SalesTerritoryEntity>(entity =>
            {
                entity.HasKey(e => e.TerritoryId);
            });

            modelBuilder.Entity<CustomerEntity>(entity =>
            {
                entity.HasKey(e => e.CustomersId);
            });
            modelBuilder.Entity<OrderEntity>(entity =>
            {
                entity.HasKey(e => e.OrderId);
            });
            modelBuilder.Entity<OrderLineEntity>(entity =>
            {
                entity.HasKey(e => e.OrderLineId);
            });
            modelBuilder.Entity<ProductLineEntity>(entity =>
            {
                entity.HasKey(e => e.ProductLineId);
            });

            modelBuilder.Entity<ProductEntity>(entity =>
            {
                entity.HasKey(e => e.ProductId);
            });
            modelBuilder.Entity<RawMaterialEntity>(entity =>
            {
                entity.HasKey(e => e.MaterialId);
            });
            modelBuilder.Entity<VendorEntity>(entity =>
            {
                entity.HasKey(e => e.VendorId);
            });
            modelBuilder.Entity<WorkCenterEntity>(entity =>
            {
                entity.HasKey(e => e.WorkCenterId);
            });
            modelBuilder.Entity<EmployeeEntity>(entity =>
            {
                entity.HasKey(e => e.EmployeeId);
            });
            modelBuilder.Entity<SkillEntity>(entity =>
            {
                entity.HasKey(e => e.SkillId);
            });
        }
    }
}
