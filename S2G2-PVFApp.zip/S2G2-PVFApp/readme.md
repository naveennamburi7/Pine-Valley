# Project: Pine Valley Furniture Company

Pine Valley Furniture Company is a DotNet Web application where store can be taken orders behalf of customers and make them process.

## Installation
#### Visual Studio 2022
#### Microsoft SQL Server 2019

## Project Set-Up
Unzip the given "S2G2-PVFApp" into the machine and double click "S2G2-PVFApp.sln" file.

## Database Setup
You can setup database in 2 ways.
### 1.Using "S2G2-PVFDB.bak" File
Find the file in given ZIP Folder and then restore it in SQL Server.

### 2.Using EF Migration
In Visual studio Select "Tools" Menu -> NuGet Package Manager -> Package Manager Console option. Then Run below commands to setup the database.

```
> add-migration [migration-name]
> update-database
```

Above commands will setup the database as we used Code First Approach.


## Conclusion

Please follow the above steps to set up the project/application in the machine to make it run successfully.

# Thank you!