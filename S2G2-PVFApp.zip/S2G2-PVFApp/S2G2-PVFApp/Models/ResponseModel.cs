﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace S2G2_PVFApp.Models
{
    public class ResponseModel
    {
        public bool IsSuccess { get; set; }
        public bool HasError { get; set; }
        public string? Message{ get; set; }
    }
}
