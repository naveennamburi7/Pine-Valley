﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblVendors")]
    public class VendorEntity : CoreEntity
    {
        [Key]
        public int VendorId { get; set; }
        public string? VendorName { get; set; }
        public string? Address { get; set; }
    }
}
