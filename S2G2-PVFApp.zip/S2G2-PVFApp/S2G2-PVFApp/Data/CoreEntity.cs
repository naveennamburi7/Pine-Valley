﻿namespace S2G2_PVFApp.Data
{
    public class CoreEntity
    {
        public DateTime? CreatedDate { get; set; } = DateTime.Now;
        public DateTime? ModifiedDate { get; set; } = DateTime.Now;
    }
}
