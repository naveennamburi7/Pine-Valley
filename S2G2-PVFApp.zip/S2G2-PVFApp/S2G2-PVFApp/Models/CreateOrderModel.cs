﻿namespace S2G2_PVFApp.Models
{
    public class CreateOrderModel
    {
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
