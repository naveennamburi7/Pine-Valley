﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblOrderLines")]
    public class OrderLineEntity : CoreEntity
    {
        [Key]
        public int OrderLineId { get; set; }
        public int Quantity { get; set; }
        public string? Status { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
    }
}
