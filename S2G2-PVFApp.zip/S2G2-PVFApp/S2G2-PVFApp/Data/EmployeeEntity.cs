﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblEmployees")]
    public class EmployeeEntity : CoreEntity
    {
        [Key]
        public int EmployeeId { get; set; }
        public string? EmployeeName { get; set; }
        public string? EmployeeAddress { get; set; }
        public int WorkCenterId { get; set; }
        public int? SupervisorId { get; set; }
        public int SkillId { get; set; }
    }
}
