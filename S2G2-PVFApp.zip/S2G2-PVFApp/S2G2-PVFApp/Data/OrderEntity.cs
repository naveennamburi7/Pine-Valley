﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblOrders")]
    public class OrderEntity : CoreEntity
    {
        [Key]
        public int OrderId { get; set; }
        public string OrderReference { get; set; } = "OR" + new Random().Next(9999, 999999);
        public int CustomerId { get; set; }
    }
}
