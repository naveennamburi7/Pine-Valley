﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblRawMaterials")]
    public class RawMaterialEntity : CoreEntity
    {
        [Key]
        public int MaterialId { get; set; }
        public string? MaterialName { get; set; }
        public string? MaterialDescription { get; set; }
       
        public decimal? Cost { get; set; }
        public string? UnitOfMeasure{ get; set; }
        public int ProductLineId { get; set; }
        public int VendorId { get; set; }
    }
}
