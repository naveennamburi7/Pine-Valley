﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using S2G2_PVFApp.Utilities;

namespace S2G2_PVFApp
{
    public class AuthorizeSessionAttribute : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext authorizeFilterContext)
        {
            if (authorizeFilterContext.HttpContext.Session.GetValue("profile") == null)
            {
                authorizeFilterContext.Result =
         new RedirectToRouteResult(new RouteValueDictionary
           {
                { "action", "Index" },
               { "controller", "Home" },
               { "returnUrl", authorizeFilterContext.HttpContext.Request.Path}
            });
                return;
            }
        }

    }
}
