﻿using S2G2_PVFApp.Data;

namespace S2G2_PVFApp.Models
{
    public class OrderDetailsModel
    {
        public OrderEntity Order { get; set; } = new OrderEntity();
        public List<OrderLineModel> OrderLines { get; set; } = new List<OrderLineModel>(); 
    }

    public class OrderLineModel
    {
        public int LineId { get; set; }
        public string? ProductName { get; set; }
        public int Quantity { get; set; }
        public string? Status { get; set; }
        public decimal? Price { get; set; }
        public DateTime? CreatedDate { get; set; }

    }
}
