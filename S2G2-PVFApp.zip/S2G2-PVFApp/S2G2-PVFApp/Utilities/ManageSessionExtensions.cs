﻿namespace S2G2_PVFApp.Utilities
{
    public static class ManageSessionExtensions
    {
        public static void SetValue(this ISession session, string key, string value)
        {
            session.SetString(key, value);
        }
        public static string? GetValue(this ISession session, string key)
        {
            var value = session.GetString(key);
            return string.IsNullOrEmpty(value) ? null :
                value;
        }
    }
}
