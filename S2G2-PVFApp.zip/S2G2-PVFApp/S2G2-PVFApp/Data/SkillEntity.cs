﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblSkills")]
    public class SkillEntity : CoreEntity
    {
        [Key]
        public int SkillId { get; set; }
        public string? SkillName { get; set; }
    }
}
