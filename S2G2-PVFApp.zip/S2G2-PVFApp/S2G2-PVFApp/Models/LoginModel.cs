﻿using System.ComponentModel.DataAnnotations;

namespace S2G2_PVFApp.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage = "Enter Username")]
        public string? UserName { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string? Password { get; set; }
    }
    public class LoginResultModel : ResponseModel
    {
        public int UserId { get; set; }
        public string? UserName { get; set; }
        public int UserType { get; set; }
    }
}
