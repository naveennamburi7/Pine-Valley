﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblSalesPersons")]
    public class SalesPersonEntity : CoreEntity
    {
        [Key]   
        public int SalesPersonId { get; set; }
        public string? SalesPersonName { get; set; }
        public string? SalesPersonFax { get; set; }
        public string? SalesPersonTelePhone { get; set; }
        public int TerritoryId { get; set; }
    }
}
