using Microsoft.EntityFrameworkCore;
using S2G2_PVFApp.Data;

var builder = WebApplication.CreateBuilder(args);

// Adding required services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddSession();
builder.Services.AddAuthentication();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
//Adding database Service
builder.Services.AddDbContext<S2G2_PVFApp_DBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("S2G2_PVFApp_DBContext")));

var app = builder.Build();

// Configuring the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
