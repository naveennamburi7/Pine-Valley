﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblProductLines")]
    public class ProductLineEntity : CoreEntity
    {
        [Key]
        public int ProductLineId { get; set; }
        public string? ProductLineName { get; set; }
    }
}
