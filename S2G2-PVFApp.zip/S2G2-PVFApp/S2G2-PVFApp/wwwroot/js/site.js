﻿$(function () {
    $("#workCenter").autocomplete({
        source: function (req, res) {
            $.ajax({
                url: '/PVFApp/SearchWorkCenters/',
                data: { "searchTerm": req.term },
                type: "POST",
                success: function (data) {
                    res($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (res) {
                    alert(res.resText);
                },
                failure: function (res) {
                    alert(res.resText);
                }
            });
        },
        select: function (e, i) {
            $("#WorkCenterId").val(i.item.val);
        },
        minLength: 1
    });

    $("#skill").autocomplete({
        source: function (req, res) {
            $.ajax({
                url: '/PVFApp/SearchSkills/',
                data: { "searchTerm": req.term },
                type: "POST",
                success: function (data) {
                    res($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (res) {
                    alert(res.resText);
                },
                failure: function (res) {
                    alert(res.resText);
                }
            });
        },
        select: function (e, i) {
            $("#SkillId").val(i.item.val);
        },
        minLength: 1
    });

    $("#supervisor").autocomplete({
        source: function (req, res) {
            $.ajax({
                url: '/PVFApp/SearchEmployees/',
                data: { "searchTerm": req.term },
                type: "POST",
                success: function (data) {
                    res($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (res) {
                    alert(res.resText);
                },
                failure: function (res) {
                    alert(res.resText);
                }
            });
        },
        select: function (e, i) {
            $("#SupervisorId").val(i.item.val);
        },
        minLength: 1
    });

    $("#territory").autocomplete({
        source: function (req, res) {
            $.ajax({
                url: '/PVFApp/SearchTerritory/',
                data: { "searchTerm": req.term },
                type: "POST",
                success: function (data) {
                    res($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (res) {
                    alert(res.resText);
                },
                failure: function (res) {
                    alert(res.resText);
                }
            });
        },
        select: function (e, i) {
            $("#TerritoryId").val(i.item.val);
        },
        minLength: 1
    });

    $("#product").autocomplete({
        source: function (req, res) {
            $.ajax({
                url: '/PVFApp/SearchProducts/',
                data: { "searchTerm": req.term },
                type: "POST",
                success: function (data) {
                    res($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (res) {
                    alert(res.resText);
                },
                failure: function (res) {
                    alert(res.resText);
                }
            });
        },
        select: function (e, i) {
            getProductData(i.item.val);
            $('#product').attr('disabled', 'disabled');
        },
        minLength: 1
    });

    $("#customer").autocomplete({
        source: function (req, res) {
            $.ajax({
                url: '/PVFApp/SearchCustomers/',
                data: { "searchTerm": req.term },
                type: "POST",
                success: function (data) {
                    res($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (res) {
                    alert(res.resText);
                },
                failure: function (res) {
                    alert(res.resText);
                }
            });
        },
        select: function (e, i) {
            $("#customerId").val(i.item.val);
        },
        minLength: 1
    });

    function getProductData(prodId) {
        $.ajax({
            url: '/PVFApp/FindProduct/',
            data: { "productId": prodId },
            type: "GET",
            success: function (data) {
                // Adding a row inside the tbody.
                $('#tableBodyId').append(`<tr id="R${data.productId}">
                     <td>${data.productId}</td>
                     <td>${data.productName}</td>
                     <td>${data.productDesc}</td>
                     <td>${$("#qty").val()}</td>
                    <td>${data.price}</td>
                    <td class="text-center">
                    <button class="btn btn-danger remove" 
                    type="button">Remove</button>
                    </td>
                </tr>`);
                $("#qty").val('');
                $("#product").val('');
                $('#buttonOrder').show()
            },
            error: function (res) {
                alert(res.resText);
            },
            failure: function (res) {
                alert(res.resText);
            }
        })
    }

    // jQuery button click event to remove a row
    $('#tableBodyId').on('click', '.remove', function () {
        $(this).closest('tr').remove();
        manageOrderButtonActivity();
    });

    function manageOrderButtonActivity() {
        if ($('#tableOrderItems tbody tr').length == 0) {
            $('#buttonOrder').hide()
        }
        else {
            $('#buttonOrder').show()
        }
    }
})