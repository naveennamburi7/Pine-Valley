﻿using Microsoft.AspNetCore.Mvc;
using S2G2_PVFApp.Models;
using S2G2_PVFApp.Utilities;
using System.Diagnostics;

namespace S2G2_PVFApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                if(model.UserName.Equals("admin") && model.Password.Equals("password"))
                {
                    HttpContext.Session.SetValue("profile", model.UserName);
                    return RedirectToAction("Index", "PVFApp");
                }
            }
            ModelState.AddModelError("error", "Invalid Username or Password. Try Again");
            return View("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}