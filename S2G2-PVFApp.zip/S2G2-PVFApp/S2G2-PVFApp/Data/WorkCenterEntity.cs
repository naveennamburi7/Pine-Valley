﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblWorkCenters")]
    public class WorkCenterEntity : CoreEntity
    {
        [Key]
        public int WorkCenterId { get; set; }
        public string? WorkCenterLocation { get; set; }
    }
}
