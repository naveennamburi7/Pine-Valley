﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblSalesTerritories")]
    public class SalesTerritoryEntity : CoreEntity
    {
        [Key]
        public int TerritoryId { get; set; }
        public string? TerritoryName { get; set;}
      
    }
}
