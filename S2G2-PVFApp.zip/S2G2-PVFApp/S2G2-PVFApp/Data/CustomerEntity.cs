﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace S2G2_PVFApp.Data
{
    [Table("tblCustomers")]
    public class CustomerEntity : CoreEntity
    {
        [Key]
        public int CustomersId { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerAddress { get; set; }
        public string? CustomerPostalCode{ get; set; }
        public string? CustomerEmail { get; set; }
        public string? CustomerMobile { get; set; }
        public int TerritoryId { get; set; }

    }
}
