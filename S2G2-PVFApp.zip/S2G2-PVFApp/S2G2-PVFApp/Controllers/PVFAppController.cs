﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using S2G2_PVFApp.Data;
using S2G2_PVFApp.Models;

namespace S2G2_PVFApp.Controllers
{
    public class PVFAppController : Controller
    {
        //Injecting DB Context
        private S2G2_PVFApp_DBContext _dbcontext;
        public PVFAppController(S2G2_PVFApp_DBContext context)
        {
            _dbcontext = context;
        }

        //PVFApp Dashboard View - Displays the Orders
        public IActionResult Index()
        {
            try
            {
                var allOrders = _dbcontext.Orders?.ToList();
                return View(allOrders);

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return View();
        }
        //Users View  for User Details
        public IActionResult Users()
        {
            try
            {
                var allUsers = _dbcontext.Customers?.ToList(); //Getting all the Users
                return View(allUsers);

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return View();
        }

        //Userdto Orders View  and Status Updates in the given view
        public IActionResult Orders()
        {
            try
            {
                var allOrders = _dbcontext.Orders?.ToList();
                return View(allOrders);

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return View();
        }

        //OrderDetails method is used to get all order details in the view
        public IActionResult OrderDetails(int orderID)
        {
            try
            {
                var orderData = _dbcontext.Orders.Find(orderID); //GEtting ORder by Id

                //Building Order Details
                var orderLines = (from orders in _dbcontext.Orders
                             join lines in _dbcontext.OrderLines on orders.OrderId equals lines.OrderId
                             join products in _dbcontext.Products on lines.ProductId equals products.ProductId
                             where orders.OrderId == orderID
                             select (new OrderLineModel
                             {
                                 LineId = lines.OrderLineId,
                                 ProductName = products.ProductName,
                                 Quantity = lines.Quantity,
                                 Status = lines.Status,
                                 CreatedDate = orders.CreatedDate,
                                 Price = products.Price,
                             }))?.ToList();
                //Result Object
                var result = new OrderDetailsModel
                {
                    Order = orderData,
                    OrderLines = orderLines
                };
                return View(result);
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            return View();
        }

        //This method is used to update the order status by the admin
        public IActionResult UpdateStatus(int orderId, string orderStatus)
        {
            try
            {
                var orderLineData = _dbcontext.OrderLines.Find(orderId); //get order
                orderLineData.Status = orderStatus;
                orderLineData.ModifiedDate = DateTime.Now;
                _dbcontext.OrderLines.Update(orderLineData);
                _dbcontext.SaveChanges();
                TempData["Success"] = "Order Status Updated Successfully!!";
                return RedirectToAction("OrderDetails", "PVFApp", new { id = orderLineData.OrderId });
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            return RedirectToAction("OrderDetails", "Orders");
        }

        //View to Add Sales Person in PVFApp Dashboard
        public async Task<IActionResult> SalesPerson(int salePeronId = 0)
        {
            var record = await _dbcontext.SalesPersons.FindAsync(salePeronId); //Get sales person details by ID
            return View(record);
        }

        // SalesPerson method is Used to Post the Sales Person data  and create/update into database
        [HttpPost]
        public async Task<IActionResult> SalesPerson(SalesPersonEntity salesPersonData)
        {
            try
            {
                if (salesPersonData.SalesPersonId == 0) //If Record Adding
                {
                    var res = await _dbcontext.SalesPersons.AddAsync(salesPersonData);
                    TempData["Success"] = "Sales Person Added Successfully!!";
                }
                else // Updating existing record in database
                {
                    var res = _dbcontext.SalesPersons.Update(salesPersonData);
                    TempData["Success"] = "Sales Person Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }


        //Manage_SalesPerson View userd to Manage Sales Persons - Edit, Delete and Update operations
        public IActionResult Manage_SalesPerson()
        {
            var salesPersons = _dbcontext.SalesPersons?.ToList();
            return View(salesPersons);
        }

        /// <summary>
        /// DeleteSalesPerson method is used to delete the Sales Person from database 
        /// </summary>
        /// <param name="salePeronId">1</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteSalesPerson(int salePeronId)
        {
            try
            {
                var salesPersonRecord = await _dbcontext.SalesPersons.FindAsync(salePeronId);
                if (salesPersonRecord != null)
                {
                    _dbcontext.SalesPersons.Remove(salesPersonRecord); //Deleting sales person by Id from the database

                    await _dbcontext.SaveChangesAsync(); //Record Saving
                }
                else // If Record not existed
                {
                    TempData["errorMessage"] = "Record Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_SalesPerson", "PVFApp");
        }

        //SalesTerritory is a View to Add Sales Territory
        public async Task<IActionResult> SalesTerritory(int salesTerritoryId = 0)
        {
            var SalesTerritoryRecord = await _dbcontext.SalesTerritories.FindAsync(salesTerritoryId);
            return View(SalesTerritoryRecord);
        }
        // Used to Post the sales Terriory data  and create/update into database for admin
        [HttpPost]
        public async Task<IActionResult> SalesTerritory(SalesTerritoryEntity salesTerritory)
        {
            try
            {
                if (salesTerritory.TerritoryId == 0) //If New Terriory Adding
                {
                    var result = await _dbcontext.SalesTerritories.AddAsync(salesTerritory);
                    TempData["Success"] = "Sales Territory Added Successfully!!";
                }
                else // Updating existing Terriory record
                {
                    var result = _dbcontext.SalesTerritories.Update(salesTerritory);
                    TempData["Success"] = "Sales Territory Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }
        //Manage_SalesTerritory View to Manage Sales Territories - Edit, Delete and Update operations
        public IActionResult Manage_SalesTerritory()
        {
            var records = _dbcontext.SalesTerritories?.ToList();
            return View(records);
        }
        /// <summary>
        /// DeleteTerritory method is used to delete the Terriory from database 
        /// </summary>
        /// <param name="TerritoryId">1</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteTerritory(int TerritoryId)
        {
            try
            {
                var record = await _dbcontext.SalesTerritories.FindAsync(TerritoryId);
                if (record != null)
                {
                    _dbcontext.SalesTerritories.Remove(record); //Deleting Terriory by Id from the table

                    await _dbcontext.SaveChangesAsync(); //Terriory Record Saving
                }
                else // If Terriory not found
                {
                    TempData["errorMessage"] = "Record Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_SalesTerritory", "PVFApp");
        }
        //ProductLines is a View to Add Product Lines
        public async Task<IActionResult> ProductLines(int productLinesId = 0)
        {
            var rec = await _dbcontext.ProductLines.FindAsync(productLinesId);
            return View(rec);
        }
        //ProductLines method is Used to Post the Product Line data  and create/update operations in database
        [HttpPost]
        public async Task<IActionResult> ProductLines(ProductLineEntity productLine)
        {
            try
            {
                if (productLine.ProductLineId == 0) //If New Product Line Adding
                {
                    var res = await _dbcontext.ProductLines.AddAsync(productLine);
                    TempData["Success"] = "Product Line Added Successfully!!";
                }
                else // Updating existing Product Line
                {
                    var res = _dbcontext.ProductLines.Update(productLine);
                    TempData["Success"] = "Product Line Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }
        //Manage_ProductLines is a view to Manage ProductLines - Edit, Delete and Update operations
        public IActionResult Manage_ProductLines()
        {
            var records = _dbcontext.ProductLines?.ToList();
            return View(records);
        }
        /// <summary>
        /// DeleteProductLine method is used to delete the ProductLine from database 
        /// </summary>
        /// <param name="productLineId">15</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteProductLine(int productLineId)
        {
            try
            {
                var rec = await _dbcontext.ProductLines.FindAsync(productLineId);
                if (rec != null)
                {
                    _dbcontext.ProductLines.Remove(rec); //Deleting ProductLine by Id from the table

                    await _dbcontext.SaveChangesAsync(); //Record ProductLine Saving
                }
                else // If ProductLine not found
                {
                    TempData["errorMessage"] = "ProductLine Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_ProductLines", "PVFApp");
        }
        //Products is a View to Add Products
        public async Task<IActionResult> Products(int productId = 0)
        {
            var rec = await _dbcontext.Products.FindAsync(productId);
            return View(rec);
        }

        // Products method is Used to Post the Product data  and create/update operation in database
        [HttpPost]
        public async Task<IActionResult> Products(ProductEntity product)
        {
            try
            {
                if (product.ProductId == 0) //If New Product Adding
                {
                    var res = await _dbcontext.Products.AddAsync(product);
                    TempData["Success"] = "Product Added Successfully!!";
                }
                else // Updating existing Product record
                {
                    var res = _dbcontext.Products.Update(product);
                    TempData["Success"] = "Product Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Product Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }

        //Manage_Products is a view to Manage Products - Edit, Delete and Update operations
        public IActionResult Manage_Products()
        {
            var products = _dbcontext.Products?.ToList();
            return View(products);
        }

        /// <summary>
        /// DeleteProduct method is used to delete the Product from database 
        /// </summary>
        /// <param name="productId">12</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteProduct(int productId)
        {
            try
            {
                var product = await _dbcontext.Products.FindAsync(productId);
                if (product != null)
                {
                    _dbcontext.Products.Remove(product); //Deleting Product by Id from the table

                    await _dbcontext.SaveChangesAsync(); //Product Record Saving
                }
                else // If Product not found
                {
                    TempData["errorMessage"] = "Product Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_Products", "PVFApp");
        }
        //RawMaterials is a View to Add Raw Materials
        public async Task<IActionResult> RawMaterials(int materialId = 0)
        {
            var rawMaterial = await _dbcontext.RawMaterials.FindAsync(materialId);
            return View(rawMaterial);
        }

        // RawMaterials method is Used to Post the Raw Materials data  and create/update operations in database
        [HttpPost]
        public async Task<IActionResult> RawMaterials(RawMaterialEntity material)
        {
            try
            {
                if (material.MaterialId == 0) //If New RawMaterial Adding
                {
                    var res = await _dbcontext.RawMaterials.AddAsync(material);
                    TempData["Success"] = "Raw Material Added Successfully!!";
                }
                else // Updating existing RawMaterial record
                {
                    var res = _dbcontext.RawMaterials.Update(material);
                    TempData["Success"] = "Raw Material Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }


        //Manage_RawMaterials is a view to Manage Raw Materials - Edit, Delete and Update operations
        public IActionResult Manage_RawMaterials()
        {
            var records = _dbcontext.RawMaterials?.ToList();
            return View(records);
        }

        /// <summary>
        /// DeleteMaterial method is used to delete the Material from database 
        /// </summary>
        /// <param name="materialId">11</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteMaterial(int materialId)
        {
            try
            {
                var material = await _dbcontext.RawMaterials.FindAsync(materialId);
                if (material != null)
                {
                    _dbcontext.RawMaterials.Remove(material); //Deleting Material by Id from the table

                    await _dbcontext.SaveChangesAsync(); //Material Record Saving
                }
                else // If Material not found
                {
                    TempData["errorMessage"] = "Material Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_RawMaterials", "PVFApp");
        }

        //Vendors is a View to Add Vendors
        public async Task<IActionResult> Vendors(int vendorId = 0)
        {
            var vendor = await _dbcontext.Vendors.FindAsync(vendorId);
            return View(vendor);
        }
        //Vendors method is Used to Post the Vendors data  and create/update operations in database
        [HttpPost]
        public async Task<IActionResult> Vendors(VendorEntity vendor)
        {
            try
            {
                if (vendor.VendorId == 0) //If New Vendor Adding
                {
                    var res = await _dbcontext.Vendors.AddAsync(vendor);
                    TempData["Success"] = "Vendor Added Successfully!!";
                }
                else // Updating existing Vendor record
                {
                    var res = _dbcontext.Vendors.Update(vendor);
                    TempData["Success"] = "Vendor Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Vendor Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }
        //Manage_Vendors is a view to Manage Vendors - Edit, Delete and Update
        public IActionResult Manage_Vendors()
        {
            var vendors = _dbcontext.Vendors?.ToList();
            return View(vendors);
        }
        /// <summary>
        /// DeleteVendor method is used to delete the Vendor from database 
        /// </summary>
        /// <param name="vendorId">19</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteVendor(int vendorId)
        {
            try
            {
                var vendor = await _dbcontext.Vendors.FindAsync(vendorId);
                if (vendor != null)
                {
                    _dbcontext.Vendors.Remove(vendor); //Deleting Vendor by Id from the table

                    await _dbcontext.SaveChangesAsync(); //Vendor Record Saving
                }
                else // If Vendor not found
                {
                    TempData["errorMessage"] = "Vendor Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_Vendors", "PVFApp");
        }
        //WorkCenters is a View to Add WorkCenters
        public async Task<IActionResult> WorkCenters(int workCenterId = 0)
        {
            var workCenter = await _dbcontext.WorkCenters.FindAsync(workCenterId);
            return View(workCenter);
        }

        //WorkCenters methos Used to Post the WorkCenters data  and create/update into database
        [HttpPost]
        public async Task<IActionResult> WorkCenters(WorkCenterEntity workCenter)
        {
            try
            {
                if (workCenter.WorkCenterId == 0) //If New WorkCenter Adding
                {
                    var res = await _dbcontext.WorkCenters.AddAsync(workCenter);
                    TempData["Success"] = "WorkCenter Added Successfully!!";
                }
                else // Updating existing WorkCenter record
                {
                    var res = _dbcontext.WorkCenters.Update(workCenter);
                    TempData["Success"] = "WorkCenter Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //WorkCenter Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }

        //Manage_WorkCenters is a view to Manage WorkCenters - Edit, Delete and Update operations
        public IActionResult Manage_WorkCenters()
        {
            var records = _dbcontext.WorkCenters?.ToList();
            return View(records);
        }

        /// <summary>
        /// DeleteWorkCenter method is used to delete the WorkCenter from database 
        /// </summary>
        /// <param name="WorkCenterid">10</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteWorkCenter(int WorkCenterid)
        {
            try
            {
                var WorkCenter = await _dbcontext.WorkCenters.FindAsync(WorkCenterid);
                if (WorkCenter != null)
                {
                    _dbcontext.WorkCenters.Remove(WorkCenter); //Deleting WorkCenter by Id from the table

                    await _dbcontext.SaveChangesAsync(); //WorkCenter Record Saving
                }
                else // If WorkCenter not found
                {
                    TempData["errorMessage"] = "WorkCenter Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_WorkCenters", "PVFApp");
        }

        //Employees is View to Add Employees
        public async Task<IActionResult> Employees(int employeeId = 0)
        {
            var employee = await _dbcontext.Employees.FindAsync(employeeId); //Getting employee by employeeId
            return View(employee);
        }

        //Employees method is Used to Post the Employee data and create/update into database
        [HttpPost]
        public async Task<IActionResult> Employees(EmployeeEntity employee)
        {
            try
            {
                if (employee.EmployeeId == 0) //If New Employee Adding
                {
                    var res = await _dbcontext.Employees.AddAsync(employee);
                    TempData["Success"] = "Employee Added Successfully!!";
                }
                else // Updating existing Employee record
                {
                    var res = _dbcontext.Employees.Update(employee);
                    TempData["Success"] = "Employee Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Employee Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }


        //Manage_Employees is a view to Manage Employees - Edit, Delete and Update operations
        public IActionResult Manage_Employees()
        {
            var employees = _dbcontext.Employees?.ToList();
            return View(employees);
        }

        /// <summary>
        /// DeleteEmployee method is used to delete the Employee from database 
        /// </summary>
        /// <param name="id">10</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteEmployee(int employeeId)
        {
            try
            {
                var employee = await _dbcontext.Employees.FindAsync(employeeId);
                if (employee != null)
                {
                    _dbcontext.Employees.Remove(employee); //Deleting Employee by Id from the table

                    await _dbcontext.SaveChangesAsync(); //Record Saving
                }
                else // If Employee not found
                {
                    TempData["errorMessage"] = "Employee Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_Employees", "PVFApp");
        }
        //Skills is aView to Add Skills 
        public async Task<IActionResult> Skills(int skillId = 0)
        {
            var skill = await _dbcontext.Skills.FindAsync(skillId);
            return View(skill);
        }

        //Skills method is Used to Post the Skills data  and create/update operations into database
        [HttpPost]
        public async Task<IActionResult> Skills(SkillEntity skill)
        {
            try
            {
                if (skill.SkillId == 0) //If New Skills Adding
                {
                    var res = await _dbcontext.Skills.AddAsync(skill);
                    TempData["Success"] = "Skill Added Successfully!!";
                }
                else // Updating existing Skills record
                {
                    var res = _dbcontext.Skills.Update(skill);
                    TempData["Success"] = "Skill Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Skills Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }


        //Manage_Skills is a view to Manage Skills - Edit, Delete and Update operations
        public IActionResult Manage_Skills()
        {
            var skill = _dbcontext.Skills?.ToList();
            return View(skill);
        }

        /// <summary>
        /// DeleteSkill method is used to delete the skill from database 
        /// </summary>
        /// <param name="skillId">1</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteSkill(int skillId)
        {
            try
            {
                var skill = await _dbcontext.Skills.FindAsync(skillId);
                if (skill != null)
                {
                    _dbcontext.Skills.Remove(skill); //Deleting skill by Id from the table

                    await _dbcontext.SaveChangesAsync(); //skill Record Saving
                }
                else // If skill not found
                {
                    TempData["errorMessage"] = "Skill Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Manage_Skills", "PVFApp");
        }


        /// <summary>
        ///AddUser method is used to return a view to Add User and Edit
        /// </summary>
        /// <param name="userId">4</param>
        /// <returns>AddUser View</returns>
        public async Task<IActionResult> AddUser(int userId = 0)
        {
            var user = await _dbcontext.Customers.FindAsync(userId); //Get User Details by Id
            return View(user);
        }
        /// <summary>
        /// DeleteCustomer is used to delete the Record from database based on record Id
        /// </summary>
        /// <param name="userId">1</param>
        /// <returns>Action</returns>
        public async Task<IActionResult> DeleteCustomer(int userId)
        {
            try
            {
                var user = await _dbcontext.Customers.FindAsync(userId); //Finding USer/Customer by Id
                if (user != null)
                {
                    _dbcontext.Customers.Remove(user); //Deleting user by given Id from the database

                    await _dbcontext.SaveChangesAsync();
                }
                else // If user not existed
                {
                    TempData["errorMessage"] = "Record Not Found!";
                }
            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }

            return RedirectToAction("Users", "PVFApp");
        }

        //AddUser mehthod is used to Create or Update the profile
        [HttpPost]
        public async Task<IActionResult> AddUser(CustomerEntity customer)
        {
            try
            {
                if (customer.CustomersId == 0) //If New Record Inserting
                {
                    var res = await _dbcontext.Customers.AddAsync(customer);
                    TempData["Success"] = "User Added Successfully!!";
                }
                else // Updating existing user record
                {
                    var res = _dbcontext.Customers.Update(customer);
                    TempData["Success"] = "User Updated Successfully!!";
                }

                await _dbcontext.SaveChangesAsync(); //Record Saving

            }
            catch (Exception exception)
            {
                TempData["errorMessage"] = exception.Message.ToString();
            }
            ModelState.Clear();
            return View();
        }

        //Returns the View to Place/Create new Order

        public IActionResult PlaceOrder()
        {
            return View();
        }
        //Placing New Order for the Customer
        [HttpPost]
        public JsonResult PlaceOrder(string orderLines)
        {
            try
            {
                //Deserializing the order lines
                var orderLineItems = JsonConvert.DeserializeObject<List<CreateOrderModel>>(orderLines);
                // Createing new Order
                var order = new OrderEntity
                {
                    CustomerId = orderLineItems[0].CustomerId
                };
                _dbcontext.Orders.Add(order);
                _dbcontext.SaveChanges();
                var orderId = order.OrderId;
                //Create Order Line Items for the new order we created
                var lineItems = new List<OrderLineEntity>();

                foreach (var line in orderLineItems)
                {
                    var lineItem = new OrderLineEntity
                    {
                        OrderId = orderId,
                        ProductId = line.ProductId,
                        Quantity = line.Quantity,
                        Status = "In Progress"
                    };
                    lineItems.Add(lineItem);
                }
                _dbcontext.OrderLines.AddRange(lineItems);
                _dbcontext.SaveChanges();
                return Json("success");
            }
            catch (Exception exception)
            {
                return Json("fail");
            }


        }

        public async Task<IActionResult> Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        #region "AutoComplete"
        /// <summary>
        /// This method is used to search the SalesTerritories based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchTerritory(string searchTerm)
        {
            var salesTerritories = (from SalesTerritories in _dbcontext.SalesTerritories
                          where !string.IsNullOrEmpty(SalesTerritories.TerritoryName) && SalesTerritories.TerritoryName.StartsWith(searchTerm)
                          select new
                          {
                              label = SalesTerritories.TerritoryName,
                              val = SalesTerritories.TerritoryId
                          }).ToList();

            return Json(salesTerritories);
        }
        /// <summary>
        /// This method is used to search the vendors based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchVendor(string searchTerm)
        {
            var vendors = (from vendor in _dbcontext.Vendors
                          where !string.IsNullOrEmpty(vendor.VendorName) && vendor.VendorName.StartsWith(searchTerm)
                          select new
                          {
                              label = vendor.VendorName,
                              val = vendor.VendorId
                          }).ToList();

            return Json(vendors);
        }
        /// <summary>
        /// This method is used to search the productLines based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchProductLines(string searchTerm)
        {
            var productLines = (from productLine in _dbcontext.ProductLines
                          where !string.IsNullOrEmpty(productLine.ProductLineName) && productLine.ProductLineName.StartsWith(searchTerm)
                          select new
                          {
                              label = productLine.ProductLineName,
                              val = productLine.ProductLineId
                          }).ToList();

            return Json(productLines);
        }
        /// <summary>
        /// This method is used to search the materials based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchMaterials(string searchTerm)
        {
            var materials = (from material in _dbcontext.RawMaterials
                          where !string.IsNullOrEmpty(material.MaterialName) && material.MaterialName.StartsWith(searchTerm)
                          select new
                          {
                              label = material.MaterialName,
                              val = material.MaterialId
                          }).ToList();

            return Json(materials);
        }
        /// <summary>
        /// This method is used to search the skill based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchSkills(string searchTerm)
        {
            var skills = (from skill in _dbcontext.Skills
                          where !string.IsNullOrEmpty(skill.SkillName) && skill.SkillName.StartsWith(searchTerm)
                          select new
                          {
                              label = skill.SkillName,
                              val = skill.SkillId
                          }).ToList();

            return Json(skills);
        }
        /// <summary>
        /// This method is used to search the workCenter based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchWorkCenters(string searchTerm)
        {
            var workCenters= (from workCenter in _dbcontext.WorkCenters
                          where !string.IsNullOrEmpty(workCenter.WorkCenterLocation) && workCenter.WorkCenterLocation.StartsWith(searchTerm)
                          select new
                          {
                              label = workCenter.WorkCenterLocation,
                              val = workCenter.WorkCenterId
                          }).ToList();

            return Json(workCenters);
        }
        /// <summary>
        /// This method is used to search the employee based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchEmployees(string searchTerm)
        {
            var employees = (from employee in _dbcontext.Employees
                          where !string.IsNullOrEmpty(employee.EmployeeName) && employee.EmployeeName.StartsWith(searchTerm)
                          select new
                          {
                              label = employee.EmployeeName,
                              val = employee.EmployeeId
                          }).ToList();

            return Json(employees);
        }
        /// <summary>
        /// This method is used to search the product based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        [HttpPost]
        public JsonResult SearchProducts(string searchTerm)
        {
            var products = (from product in _dbcontext.Products
                          where !string.IsNullOrEmpty(product.ProductName) && product.ProductName.StartsWith(searchTerm)
                          select new
                          {
                              label = product.ProductName,
                              val = product.ProductId
                          }).ToList();

            return Json(products);
        }
        /// <summary>
        /// This method is used to search the user based on given searchterm
        /// </summary>
        /// <param name="searchTerm"></param>
        /// <returns>result</returns>
        public JsonResult SearchCustomers(string searchTerm)
        {
            var users = (from user in _dbcontext.Customers
                          where !string.IsNullOrEmpty(user.CustomerName) && user.CustomerName.StartsWith(searchTerm)
                          select new
                          {
                              label = user.CustomerName,
                              val = user.CustomersId
                          }).ToList();

            return Json(users);
        }
        /// <summary>
        /// This method is used to find the PRoduct by product Id
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult FindProduct(int productId)
        {
            var product = _dbcontext.Products.Find(productId);
            return Json(product);
        }
        #endregion
    }
}
